# Maya Vale Finds

Statische Startseite für den Aufbau einer eigenen Affiliate-Website.

## Enthalten
- responsive Startseite
- Produktkarten als Platzhalter
- Amazon-Partner-Hinweis
- Impressum-Platzhalter
- Datenschutz-Platzhalter

## Vor Veröffentlichung
1. Impressum mit echten Pflichtangaben ausfüllen.
2. Datenschutz an Hosting/Analytics/Cookies anpassen.
3. Nur echte Produkte und korrekte Produktinformationen einsetzen.
4. Affiliate-Links klar kennzeichnen.
5. Keine Amazon-Produktbilder einfach kopieren; nur rechtmäßig nutzbare Bilder bzw. zulässige Amazon-Werbemittel verwenden.

## Schnell deployen
### GitHub Pages
- Neues Repository erstellen, z. B. `maya-vale-finds`
- alle Dateien hochladen
- Settings → Pages → Deploy from branch → `main` / root

Alternativ: Netlify, Cloudflare Pages oder normaler Webhoster.
